﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class SaleMenu : Form
    {
        Model1 db = new Model1();
        public SaleMenu()
        {
            InitializeComponent();
        }

        private void SaleMenu_Load(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.ToList();
            productBindingSource.DataSource = db.Product.ToList();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //Сортировка по приоритетам
        {
            if (checkBox1.Checked)
            {
                agentBindingSource.DataSource = db.Agent.OrderByDescending(ag => ag.Priority).ToList();
            }
            else
            {
                agentBindingSource.DataSource = db.Agent.OrderBy(ag => ag.Priority).ToList();
            }
        }

        private void button2_Click(object sender, EventArgs e) //Сортировка по типам
        {
            agentBindingSource.DataSource = db.Agent.OrderBy(ag => ag.AgentTypeID).ToList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e) //Поиск
        {
            string s = textBox1.Text.ToUpper();
            agentBindingSource.DataSource = db.Agent.Where(p => p.Title.ToUpper().Contains(s)).ToList();
        }

        private void agentBindingSource_CurrentChanged(object sender, EventArgs e) //Подгрузка изображений
        {
            Agent agent = (Agent)agentBindingSource.Current;
            try
            {
                if (agent == null) return;
                if (agent.Logo != "")
                {
                    string str = agent.Logo.Substring(1);
                    LogoPict.Image = Image.FromFile(str);
                }
                else
                {
                    LogoPict.Image = Image.FromFile("agents\\picture.png");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
