﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class AgentsMenu : Form
    {
        Model1 db = new Model1();
        public AgentsMenu()
        {
            InitializeComponent();
        }

        private void AgentsMenu_Load(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.ToList();
        }

        private void button1_Click(object sender, EventArgs e)  //ДОБАВЛЕНИЕ
        {
            Agent agent = (Agent)agentBindingSource.Current;
            AgentRED frm = new AgentRED();
            frm.db = db;
            frm.agent = null;
            DialogResult dr = frm.ShowDialog(); ;
            if (dr == DialogResult.OK)
            {
                agentBindingSource.DataSource = null;
                agentBindingSource.DataSource = db.Agent.ToList();
            }
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)  //РЕДАКТИРОВАНИЕ
        {
            Agent agent = (Agent)agentBindingSource.Current;
            AgentRED frm = new AgentRED();
            frm.db = db;
            frm.agent = agent;
            DialogResult dr = frm.ShowDialog(); ;
            if (dr == DialogResult.OK)
            {
                agentBindingSource.DataSource = null;
                agentBindingSource.DataSource = db.Agent.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e) //УДАЛЕНИЕ
        {
            Agent agent = (Agent)agentBindingSource.Current;
            DialogResult dr = MessageBox.Show("Удалить эту запись ?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                db.Agent.Remove(agent);
                try
                {
                    db.SaveChanges();
                    agentBindingSource.DataSource = db.Agent.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.InnerException.InnerException.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
