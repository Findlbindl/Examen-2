﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Games
{
    public partial class AgentRED : Form
    {
        public Model1 db { get; set; }
        public Agent agent { get; set; }

        public AgentRED()
        {
            InitializeComponent();
        }

        private void AgentRED_Load(object sender, EventArgs e)
        {
            if (agent == null)
            {
                agentBindingSource.AddNew();

                Text = " Добавление нового Агента ";
            }
            else
            {
                agentBindingSource.Add(agent);
                iDTextBox.ReadOnly = true;
                Text = " Корректировка Агента " + agent.ID;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (agent == null)
            {
                agent = (Agent)agentBindingSource.List[0];
                db.Agent.Add(agent);
            }
            try
            {
                db.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Ошибка ");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
